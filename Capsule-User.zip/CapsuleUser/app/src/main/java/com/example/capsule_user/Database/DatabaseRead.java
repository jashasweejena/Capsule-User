package com.example.capsule_user.Database;

import android.os.Bundle;
import android.util.Log;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.example.capsule_user.R;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.FirebaseApp;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class DatabaseRead extends AppCompatActivity {

    private static final String TAG = "DatabaseRead";
    DatabaseReference myRef;
    private FirebaseDatabase database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_database_read);

        initialize();
        read();
        writeData();

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
    }

    private void initialize() {
        FirebaseApp.initializeApp(this);
        database = FirebaseDatabase.getInstance();
        FirebaseDatabase.getInstance().setPersistenceEnabled(true);
        myRef = FirebaseDatabase.getInstance().getReference();
    }

    private void read() {
        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
//                String value = dataSnapshot.child("1").getValue(String.class);
//                Log.d(TAG, "Value is: " + value);
//                Iterator<DataSnapshot> iterator = dataSnapshot.getChildren().iterator();
//                while(iterator.hasNext()){
//                    Toast.makeText(DatabaseRead.this, "" + dataSnapshot.getChildren().iterator().toString(), Toast.LENGTH_SHORT).show();
//                    Log.d(TAG, "onDataChange: " + iterator.next());
//
//                }

//                Log.d(TAG, "onDataChange: " + dataSnapshot.getChildrenCount());
                for(DataSnapshot ds : dataSnapshot.getChildren()){
//                    Log.d(TAG, "onDataChange: " + ds.getValue());
                }
                Log.d(TAG, "onDataChange: ");


            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }

    private void writeData(){
        Medicine med = new Medicine();
        med.setDesc("Test description 2");
        med.setPrice(100);
        med.setQty(200);
        myRef.push().setValue(med);
    }

//    private void showData(DataSnapshot snapshot){
//        for(DataSnapshot ds : snapshot.getChildren()){
//            Medicine med = new Medicine();
//            med.setDesc(ds.child());
//        }
//        int count = (int) snapshot.getChildrenCount();
//        for(int i = 1; i <= count; i++){
//            DataSnapshot ds = snapshot.child("" + i);
//            Medicine med = new Medicine();
//            med.setDesc(ds.get);
//        }
//    }

}
